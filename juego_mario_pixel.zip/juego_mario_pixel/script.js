const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");

let canvasWidth = window.innerWidth; 
let canvasHeight = window.innerHeight; 
canvas.width = canvasWidth;
canvas.height = canvasHeight;

let x = 50;
let y = canvasHeight - 100;
let vy = 0;
let gravity = 0.5;
let jumping = false;
let coins = [{ x: 300, y: canvasHeight - 100 }];
let enemy = { x: 500, y: canvasHeight - 100, speed: 0.5 };
let score = 0;
let gameOver = false;
let timeLeft = 30;
let vidas = 3;

let leftPressed = false;
let rightPressed = false;

const mario = new Image();
const coin = new Image();
const enemigo = new Image();
mario.src = "assets/mario.png";
coin.src = "assets/coin.png";
enemigo.src = "assets/enemigo.png";

const coinSound = document.getElementById("coinSound");
const defeatSound = new Audio("assets/defeat.mp3");

let imagesLoaded = false;

// Función para comprobar si todas las imágenes se han cargado
function checkImagesLoaded() {
  if (mario.complete && coin.complete && enemigo.complete) {
    imagesLoaded = true;
  }
}

mario.onload = checkImagesLoaded;
coin.onload = checkImagesLoaded;
enemigo.onload = checkImagesLoaded;

function draw() {
  if (!imagesLoaded) {
    return; // No dibujamos hasta que las imágenes estén cargadas
  }

  ctx.clearRect(0, 0, canvas.width, canvas.height);

  // Suelo
  ctx.fillStyle = "#228B22";
  ctx.fillRect(0, canvasHeight - 40, canvas.width, 40);

  // Jugador
  ctx.drawImage(mario, x, y, 32, 32);

  // Monedas
  coins.forEach((c) => {
    ctx.drawImage(coin, c.x, c.y, 20, 20);
  });

  // Enemigo
  ctx.drawImage(enemigo, enemy.x, enemy.y, 32, 32);

  // Marcadores
  ctx.fillStyle = "white";
  ctx.font = "20px Arial";
  ctx.fillText(`Puntos: ${score}`, 10, 30);
  ctx.fillText(`Tiempo: ${timeLeft}`, 10, 60);
  ctx.fillText(`Vidas: ${vidas}`, canvas.width - 100, 30);
}

function update() {
  if (leftPressed) x -= 3;
  if (rightPressed) x += 3;

  vy += gravity;
  y += vy;

  if (y > canvasHeight - 100) {
    y = canvasHeight - 100;
    vy = 0;
    jumping = false;
  }

  enemy.x -= enemy.speed;
  if (enemy.x < -32) {
    enemy.x = canvas.width + Math.random() * 200;
  }

  coins.forEach((c, index) => {
    if (x < c.x + 20 && x + 32 > c.x && y < c.y + 20 && y + 32 > c.y) {
      score++;
      coinSound.play();
      coins.splice(index, 1);
      coins.push({ x: Math.random() * (canvas.width - 20), y: canvasHeight - 100 });
    }
  });

  if (
    x < enemy.x + 32 &&
    x + 32 > enemy.x &&
    y < enemy.y + 32 &&
    y + 32 > enemy.y
  ) {
    vidas--;
    if (vidas <= 0) {
      gameOver = true;
      document.getElementById("gameOver").style.display = "block";
      document.getElementById("gameOver").innerHTML = `
        ¡Game Over!<br>Perdiste todas las vidas.<br>
        <button onclick="reiniciarJuego()">Volver a jugar</button>
      `;
      defeatSound.play();
    } else {
      x = 50;
      y = canvasHeight - 100;
      vy = 0;
    }
  }
}

function gameLoop() {
  if (!gameOver) {
    update();
    draw();
    requestAnimationFrame(gameLoop);
  }
}

function startTimer() {
  timeLeft = 30;
  let timer = setInterval(() => {
    if (!gameOver) {
      timeLeft--;
      if (timeLeft <= 0) {
        gameOver = true;
        document.getElementById("gameOver").style.display = "block";
        document.getElementById("gameOver").innerHTML = `
          ¡Se acabó el tiempo!<br>
          <button onclick="reiniciarJuego()">Volver a jugar</button>
        `;
        defeatSound.play();
        clearInterval(timer);
      }
    } else {
      clearInterval(timer);
    }
  }, 1000);
}

function reiniciarJuego() {
  x = 50;
  y = canvasHeight - 100;
  vy = 0;
  jumping = false;
  score = 0;
  coins = [{ x: 300, y: canvasHeight - 100 }];
  enemy = { x: 500, y: canvasHeight - 100, speed: 0.5 };
  vidas = 3;
  timeLeft = 30;
  gameOver = false;
  document.getElementById("gameOver").style.display = "none";
  gameLoop();
  startTimer();
}

// Teclado
document.addEventListener("keydown", function (e) {
  if (e.code === "ArrowLeft") leftPressed = true;
  if (e.code === "ArrowRight") rightPressed = true;
  if (e.code === "Space" && !jumping) {
    vy = -15;
    jumping = true;
  }
});

document.addEventListener("keyup", function (e) {
  if (e.code === "ArrowLeft") leftPressed = false;
  if (e.code === "ArrowRight") rightPressed = false;
});

// Botones táctiles
function moverIzquierda() {
  x -= 5;
}

function moverDerecha() {
  x += 5;
}

function saltar() {
  if (!jumping) {
    vy = -15;
    jumping = true;
  }
}

window.onload = () => {
  gameLoop();
  startTimer();
};
